Modify and repair the supplied reservation app. The baseline contract is below.
A customer reports that Reset leaves an old reservation visible; fix that bug.
Add a party size, initially 1, visible as "Guests: N", with "Add guest" and
"Remove guest" buttons. Clamp size to 1..6. Show a reactive "Total: EUR N" at EUR 20
per guest. Successful Reserve now shows "Reserved for NAME (N guests)". Later size
or name edits must not change that saved confirmation until Reserve is pressed.
Reset must restore empty name, "Not reserved", size 1 and total EUR 20. Keep the
original form behavior, validation, focus and fresh reload behavior.

Baseline contract:
Build a browser-local reservation app with a reusable reservation editor component.
Show a heading "Reservation", an input with accessible label "Guest name", and
buttons "Reserve" and "Reset". Initially the name is empty and visible status is
"Not reserved". Reserve with an empty name shows "Name required". With any nonempty
name it shows "Reserved for NAME" using the exact typed name as text (never HTML).
Typing must retain keyboard focus. Editing the name must not change the last
reservation until Reserve is pressed again. Reset clears both name and status.
The form must not navigate or reload when submitted. Reload starts fresh.
No backend, persistence, network data or styling requirements. Preserve these
behaviors in later changes. Use the assigned stack for application logic.
