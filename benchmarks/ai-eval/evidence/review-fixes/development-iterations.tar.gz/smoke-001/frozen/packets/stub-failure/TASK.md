Build a browser-local reservation app with a reusable reservation editor component.
Show a heading "Reservation", an input with accessible label "Guest name", and
buttons "Reserve" and "Reset". Initially the name is empty and visible status is
"Not reserved". Reserve with an empty name shows "Name required". With any nonempty
name it shows "Reserved for NAME" using the exact typed name as text (never HTML).
Typing must retain keyboard focus. Editing the name must not change the last
reservation until Reserve is pressed again. Reset clears both name and status.
The form must not navigate or reload when submitted. Reload starts fresh.
No backend, persistence, network data or styling requirements. Preserve these
behaviors in later changes. Use the assigned stack for application logic.
